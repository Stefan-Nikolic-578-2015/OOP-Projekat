package tekuci_racun;

public class GoldPaket extends Racun {

	GoldPaket(String brTekRac) {
		super(brTekRac);
	}
	
	public float mesecnoOdrzavanje() {
		return 500f;
	}
	
	public float kredit(float suma, int brMeseci) {
		if (suma>300000f) {
			System.out.println("U gold paketu ne mozete uzeti kredit veci od 300000 dinara!");
			return 0;
		}
		else if (brMeseci>36) {
			System.out.println("U gold paketu ne mozete uzeti kredit sa rokom otplate vecim od 36 meseci!");
			return 0;
		}
		else
		{
			return (suma*0.05f*brMeseci/12.0f + suma);
		}
	}
	
	public float zaduzenjeBezKamate(float suma, int brMeseci) {
		if (suma>30000f) {
			System.out.println("U gold paketu zaduzenje bez kamate moze biti najvise 30000 dinara!");
			return 0;
		}
		else if (brMeseci>9) {
			System.out.println("U gold paketu se ne mozete zaduziti bez kamate sa rokom otplate vecim od 9 meseci!");
			return 0;
			}
		else
		{
			return suma;
		}
	}
}
