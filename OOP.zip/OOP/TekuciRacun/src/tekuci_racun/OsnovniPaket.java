package tekuci_racun;

public class OsnovniPaket extends Racun {
	
	OsnovniPaket(String brTekRac) {
		super(brTekRac);
	}
	
	public float mesecnoOdrzavanje() {
		return 100f;
	}
	
	public float kredit(float suma, int brMeseci) {
		if (suma>100000f) {
			System.out.println("U osnovnom paketu ne mozete uzeti kredit veci od 100000 dinara!");
			return 0;
		}
		else if (brMeseci>12) {
			System.out.println("U osnovnom paketu ne mozete uzeti kredit sa rokom otplate vecim od 12 meseci!");
			return 0;
		}
		else
		{
			return (suma*0.10f*brMeseci/12.0f + suma);
		}
	}
	
	public float zaduzenjeBezKamate(float suma, int brMeseci) {
		if (suma>10000f) {
			System.out.println("U osnovnom paketu zaduzenje bez kamate moze biti najvise 10000 dinara!");
			return 0;
		}
		else if (brMeseci>3) {
			System.out.println("U osnovnom paketu se ne mozete zaduziti bez kamate sa rokom otplate vecim od 3 meseca!");
			return 0;
		}
		else
		{
			return suma;
		}
	}
}
