package tekuci_racun;

import java.util.Scanner;

public class IzvodTekucegRacuna {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		final int FIKSNI_BROJ_BANKE = 556;
		final int KONTROLNI_BROJ = 33;
	    String brTekRac = FIKSNI_BROJ_BANKE + "-" + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + (int)(Math.random()*10) + "-" + KONTROLNI_BROJ;
		Racun[] racun = new Racun[100];
	    System.out.println("Dobrodosli u online otvaranje tekuceg racuna!" +
				"\n\nU ponudi imamo tri paketa: Osnovni, Premium i Gold." +
				"\nKod osnovnog paketa, mesecno odrzanje je 100 dinara, kod premium paketa 200 dinara, a kod gold paketa 300 dinara." +
				"\nKrediti koje mozete dobiti:" +
				"\n\tOsnovni paket: Do 100000 dinara na najvise 12 meseci, sa kamatom od 10%." +
				"\n\tPremium paket: Do 200000 dinara na najvise 24 meseca, sa kamatom od 7,5%." +
				"\n\tGold paket: Do 300000 dinara na najvise 36 meseci, sa kamatom od 5%." +
				"\n\nZaduzenja bez kamate, poput administrativinh zabrana, odlozenih placanja i slicno, koje mozete dobiti su:" +
				"\n\tOsnovni paket: Do 10000 dinara na najvise 3 meseca." +
				"\n\tPremium paket: Do 20000 dinara na najvise 6 meseca" +
				"\n\tGold paket: Do 30000 dinara na najvise 9 meseci.");
		boolean p = true;
		while (p) {
			System.out.println("\nIzaberite tip tekuceg racuna koji zelite:");
			String paket = in.nextLine();
		
			if (paket.equals("Osnovni")) {
				racun[0] = new OsnovniPaket(brTekRac);
				p = false;
			}
			else if (paket.equals("Premium")) {
				racun[0] = new PremiumPaket(brTekRac);
				p = false;
			}
			else if (paket.equals("Gold")) {
				racun[0] = new GoldPaket(brTekRac);
				p=false;
			}
			else
			{
				System.out.println("Uneli ste nepostojeci paket.");
			}
		}
		System.out.println("\nVas broj tekuceg racuna je: " + racun[0].getBrTekRac());
		
		String provera = "Da";
		while (!(provera.equals("Ne"))) {
			System.out.println("\nKoju akciju zelite preduzeti (Provera stanja, Uplata, Isplata, Kredit, Zaduzenje?)");
			String akcija = in.nextLine();
			switch (akcija) {
				case ("Provera stanja") :
					System.out.println("Stanje Vaseg racuna je " + racun[0].getTrStanje());
					break;
				case ("Uplata"):
					System.out.println("Koliko novca zelite da uplatite na svoj racun?");
					float uplata = in.nextFloat();
					racun[0].uplata(uplata);
					System.out.println("Vase trenutno stanje je: " + racun[0].getTrStanje());
					break;
				case ("Isplata"):
					System.out.println("Koliko novca zelite da podignete sa racuna?");
					float isplata = in.nextFloat();
					racun[0].isplata(isplata);
					System.out.println("Vase trenutno stanje je: " + racun[0].getTrStanje());
					break;
				case ("Kredit"):
					System.out.println("U kom iznosu zelite da podignete kredit?");
					float suma = in.nextFloat();
					System.out.println("Na koji period otplate?");
					int brMeseci = in.nextInt();
					if (racun[0].kredit(suma, brMeseci)>0) {
						if (racun[0].getTrStanje()<(racun[0].kredit(suma, brMeseci)/brMeseci + racun[0].mesecnoOdrzavanje())) {
							System.out.println("Na racunu nemate dovoljno novca za prvu ratu!");
						}
						else
						{
							System.out.println("Odobren Vam je kredit!" + 
									"\nTrenutno stanje na Vasem racunu je: " + (racun[0].getTrStanje() - (racun[0].kredit(suma, brMeseci)/brMeseci + racun[0].mesecnoOdrzavanje())));
							System.out.println("Ukupan iznos kredita sa uracunatom kamatom je: " + racun[0].kredit(suma, brMeseci));
							System.out.println("Iznos jedne rate kredita je: " + racun[0].kredit(suma, brMeseci)/brMeseci);
						}
					}	
					break;
				case ("Zaduzenje"):
					System.out.println("U kom iznosu zelite da se zaduzite bez kamate?");
					float suma1 = in.nextFloat();
					System.out.println("Na koji period otplate?");
					int brMeseci1 = in.nextInt();
					if (racun[0].zaduzenjeBezKamate(suma1, brMeseci1)>0) {
						if (racun[0].getTrStanje()<(racun[0].zaduzenjeBezKamate(suma1, brMeseci1)/brMeseci1 + racun[0].mesecnoOdrzavanje())) {
							System.out.println("Na racunu nemate dovoljno novca za prvu ratu!");
						}
						else
						{
							System.out.println("Odobreno Vam je zaduzenje bez kamate!" + 
									"\nTrenutno stanje na Vasem racunu je: " + (racun[0].getTrStanje() - (racun[0].zaduzenjeBezKamate(suma1, brMeseci1)/brMeseci1 + racun[0].mesecnoOdrzavanje())));
							System.out.println("Ukupan iznos zaduzenja bez kamate je: " + racun[0].zaduzenjeBezKamate(suma1, brMeseci1));
							System.out.println("Iznos jedne rate zaduzenja je: " + racun[0].zaduzenjeBezKamate(suma1, brMeseci1)/brMeseci1);
						}
					}				
					break;
				default: System.out.println("Unesite ispravnu akciju!");
					break;
			}
			System.out.println("\nDa li zelite novu akciju?" +
									"\nUnesite Da ili Ne.");
			String provera2 = in.nextLine();
			String provera1 = in.nextLine();
			if (provera1.equals("Ne")) {
				provera = provera1;
			}
			
		}
		
	in.close();	
	}
}
