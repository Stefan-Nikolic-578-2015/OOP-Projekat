package tekuci_racun;

public abstract class Racun {
	private String brTekRac;
	private float trStanje;
	private float zaduzenje;
	
	
	protected Racun(String brTekRac) {
		this.brTekRac=brTekRac;
		this.trStanje=0;
		this.zaduzenje=0;
	}
	
	public String getBrTekRac () {
		return brTekRac;
	}
	public void setBrTekRac(String brTekRac) {
		this.brTekRac=brTekRac;
	}
	
	public float getTrStanje () {
		return trStanje;
	}
	public void setTrStanje(float trStanje) {
		this.trStanje=trStanje;
	}
	
	public float getZaduzenje () {
		return zaduzenje;
	}
	public void setZaduzenje(float zaduzenje) {
		this.zaduzenje=zaduzenje;
	}
	
	public void uplata(float uplata) {
		this.trStanje+=uplata;
	}
	
	public void isplata(float isplata) {
		this.trStanje-=isplata;
	}
	
	public abstract float mesecnoOdrzavanje();
	
	public abstract float kredit(float suma, int brMeseci);
	
	public abstract float zaduzenjeBezKamate(float suma, int brMeseci);
}
