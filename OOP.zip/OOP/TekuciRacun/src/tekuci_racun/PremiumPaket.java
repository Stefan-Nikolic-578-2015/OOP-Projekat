package tekuci_racun;

public class PremiumPaket extends Racun {

	PremiumPaket(String brTekRac) {
		super(brTekRac);
	}
	
	public float mesecnoOdrzavanje() {
		return 300f;
	}
	
	public float kredit(float suma, int brMeseci) {
		if (suma>200000f) {
			System.out.println("U premium paketu ne mozete uzeti kredit veci od 200000 dinara!");
			return 0;
		}
		else if (brMeseci>24) {
			System.out.println("U premium paketu ne mozete uzeti kredit sa rokom otplate vecim od 24 meseci!");
			return 0;
		}
		else
		{
			return (suma*0.075f*brMeseci/12.0f + suma);
		}
	}
	
	public float zaduzenjeBezKamate(float suma, int brMeseci) {
		if (suma>20000f) {
			System.out.println("U premium paketu zaduzenje bez kamate moze biti najvise 20000 dinara!");
			return 0;
		}
		else if (brMeseci>6) {
			System.out.println("U premiuim paketu se ne mozete zaduziti bez kamate sa rokom otplate vecim od 6 meseci!");
			return 0;
			}
		else
		{
			return suma;
		}
	}
}
